# Guide Technique - API REST

## Architecture API

Notre API REST suit les principes RESTful :

### Endpoints Principaux
- GET /api/v1/users - Liste des utilisateurs
- POST /api/v1/users - Créer utilisateur
- GET /api/v1/users/{id} - Détails utilisateur
- PUT /api/v1/users/{id} - Modifier utilisateur
- DELETE /api/v1/users/{id} - Supprimer utilisateur

### Authentification
- JWT tokens avec expiration 24h
- Refresh tokens pour renouvellement
- API keys pour les services internes

### Codes de Réponse
- 200 OK - Succès
- 201 Created - Ressource créée
- 400 Bad Request - Erreur client
- 401 Unauthorized - Non authentifié
- 403 Forbidden - Non autorisé
- 404 Not Found - Ressource non trouvée
- 500 Internal Server Error - Erreur serveur

### Rate Limiting
- 1000 requêtes par heure pour les utilisateurs
- 10000 requêtes par heure pour les services
